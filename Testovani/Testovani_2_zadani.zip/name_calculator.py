# TODO: implementujte kód podle zadání
class Calculator:
    def _check_numbers(self, a, b):
        pass

    def add(self, a, b):
        pass

    def subtract(self, a, b):
        pass

    def multiply(self, a, b):
        pass

    def divide(self, a, b):
       pass